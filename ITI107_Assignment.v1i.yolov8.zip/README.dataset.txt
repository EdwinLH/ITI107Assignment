# ITI107 Assignment > 2024-12-21 11:54am
https://universe.roboflow.com/iti107-i17op/iti107-assignment-pquud

Provided by a Roboflow user
License: CC BY 4.0

