# ITI107 Assignment > 2024-12-29 11:41am
https://universe.roboflow.com/iti107-i17op/iti107-assignment-pquud

Provided by a Roboflow user
License: CC BY 4.0

