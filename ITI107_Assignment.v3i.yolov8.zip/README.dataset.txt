# ITI107 Assignment > 2024-12-25 12:21pm
https://universe.roboflow.com/iti107-i17op/iti107-assignment-pquud

Provided by a Roboflow user
License: CC BY 4.0

